# Android-Activity-Lifecycle

Simple Android activity lifecycle example with two different activities to see how the lifecycle callbacks work.

* onCreate()
* onStart()
* onResume()
* onPause()
* onStop()
* onDestroy()

Don't forget to check Logs. (don't forget to set the logs for *Errors* to easily see them)

